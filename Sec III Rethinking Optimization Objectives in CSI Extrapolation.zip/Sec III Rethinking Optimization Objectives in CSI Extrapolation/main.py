'''
 @ File: main.py
 @ Time: 2022/10/15
 @ Description: Run this script to train and evaluate the model. The loss function type could be changed by modifying Line 84-97.
'''
import torch
import numpy as np
import scipy.io as sio
import time
from utils.dataset import CSIDataset
from torch.utils.data import DataLoader
from models.model import Model
from utils.train_eval import train_eval
from utils.eval import eval


def main(training_time=1, epoch_num=600, batch_size=64, sigma=2.26e-10, lr=1e-4, minlr=1e-6):
    """main function. Run this function to train and evaluate the model. Results are saved in MATLAB data file.

    Args:
        training_time (int, optional): training times. Defaults to 1.
        epoch_num (int, optional): epoch number in each training time. Defaults to 600.
        batch_size (int, optional): batch size. Defaults to 64.
        sigma (float, optional): power of additive gauss noise. Defaults to 2.26e-10.
        lr (float, optional): learning rate. Defaults to 1e-4.
        minlr (float, optional): minimum learning rate. note that this is not used here since lr_scheduler has not been applied. Defaults to 1e-6.
    """

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    cur_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    train_folder = './data/train'
    eval_folder = './data/validation'
    weight = 160.4628
    num_RB = 8
    version_name = 'Fused'

    print(version_name)
    print('device:%s' % device)
    print('batch_size:%d' % batch_size)
    print('sigma:%e' % sigma)
    print('lr and minlr:(%e,%e)' % (lr, minlr))
    print('cur_time:%s' % cur_time)
    print('weight=%.3f' % weight)
    print('-----------------------------------')

    train_set = CSIDataset(path=train_folder,
                           batch_size=batch_size,
                           device=device)
    eval_set = CSIDataset(path=eval_folder,
                          batch_size=batch_size,
                          device=device)

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    eval_loader = DataLoader(eval_set, batch_size=batch_size, shuffle=False)

    loss_train = np.zeros((training_time, epoch_num))
    # 3: NMSE, rate, cossim; 10: evaluation are done 10 times in each epoch
    loss_eval = np.zeros((3, num_RB, training_time, epoch_num * 10 + 1))

    for idx in range(training_time):
        print('Train %dth time' % (idx+1))

        model = Model().to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr)
        lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=0.5,
            patience=5,
            verbose=True,
            threshold=0.0001,
            threshold_mode='rel',
            cooldown=0,
            min_lr=minlr,
            eps=1e-10)

        # evaluate the model before training
        NMSE_loss, rate_loss, cossim_loss = eval(model, eval_loader, sigma)
        loss_eval[0, :, idx, 0] = NMSE_loss
        loss_eval[1, :, idx, 0] = rate_loss
        loss_eval[2, :, idx, 0] = cossim_loss

        for epoch in range(epoch_num):
            ############################
            # MSELoss: set use_fused_loss=False;
            # RateLoss: set use_fused_loss=True, weight=0;
            # FusedLoss: set use_fused_loss=True, weight>0;
            # Two stage: use the code in the comment below;
            epoch_loss_train, epoch_loss_eval = train_eval(model, train_loader, eval_loader,
                                                           optimizer, weight, sigma, use_fused_loss=True)
            # if epoch < 100:
            #     epoch_loss_train, epoch_loss_eval = train_eval(model, train_loader, eval_loader,
            #                                                    optimizer, weight, sigma, use_fused_loss=False)
            # else:
            #     epoch_loss_train, epoch_loss_eval = train_eval(model, train_loader, eval_loader,
            #                                                    optimizer, weight, sigma, use_fused_loss=True)
            ############################
            loss_train[idx, epoch] = epoch_loss_train
            loss_eval[:, :, idx, epoch*10+1:(epoch+1)*10+1] = epoch_loss_eval

            rate_losses = epoch_loss_eval[1, :, -1]

            print('Epoch %d eval rate:%.2f' %
                  (epoch, np.mean(rate_losses.squeeze())))

            # save model
            if (epoch + 1) % 5 == 0:
                checkpoint_name = './checkpoints/' + \
                    version_name + '_checkpoint' + str(idx) + '.pt'

                checkpoint = {
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'scheduler_state_dict': lr_scheduler.state_dict()
                }
                torch.save(checkpoint, checkpoint_name)

            # save results into mat file
            mat_name = './record/' + version_name + '_result.mat'
            sio.savemat(mat_name, {
                'loss_train': loss_train,
                'loss_eval': loss_eval,
            })


if __name__ == '__main__':
    main()
