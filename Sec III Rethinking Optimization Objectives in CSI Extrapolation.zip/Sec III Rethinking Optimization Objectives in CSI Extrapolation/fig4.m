%{
 @ File: Figure4.m
 @ Time: (UTC+8) 2024/01/26 11:35:12
 @ Description: Run this script to generate Figure 4 in the paper.
%}

clc; clear; close all;

load("./record/Fused_result.mat");
rate1 = squeeze(mean(mean(loss_eval(2, :, :, :), 2), 3));
load("./record/TwoStage_result.mat");
rate2 = squeeze(mean(mean(loss_eval(2, :, :, :), 2), 3));
load("./record/Rate_result.mat");
rate3 = squeeze(mean(mean(loss_eval(2, :, :, :), 2), 3));
load("./record/MSE_result.mat");
rate4 = squeeze(mean(mean(loss_eval(2, :, :, :), 2), 3));

figure(1)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
plot(0:0.1:600, rate3, 'LineWidth', 1.5, 'Color', '#3498db');
plot(0:0.1:600, rate4, 'LineWidth', 1.5, 'Color', [0.5 0.3 0.7]);
xlabel('Epoch');
ylabel('Spectral efficiency (bps/Hz)');
legend('Linear fusion loss', 'Two-stage fusion loss', 'Spectral efficiency loss', 'MSE loss', 'Location', 'southeast');
xlim([0, 600]);
ylim([20, 37]);
