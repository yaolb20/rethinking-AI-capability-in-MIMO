'''
 @ File: rate_for_multi_UE.py
 @ Time: (UTC+8) 2023/08/21 13:03:37
 @ Descriptiosn: Calculate the sum rate of the system
'''
import torch
import math

def rate_for_multi_UE(V, H, sigma=2.26e-10):
    """calculate the sum rate of the system

    Args:
        V (tensor): predicted channel with size (num_RB, batch_size, num_UE, BS_antenna)
        H (tensor): downlink channel with size (num_RB, batch_size, num_UE, BS_antenna)
        sigma (float, optional): amplitude of additive gauss noise. Defaults to 2.26e-10.

    Returns:
        mean_sum_rate (tensor): sum rate of the system
    """
    P = 20000 # transmit power
    K = 5 # number of UE

    # calculate ZF precoding matrix
    BS_precoding = V # V = (R, batch_size, K, M)
    BS_ZF = torch.linalg.pinv(BS_precoding)
    BS_ZF = BS_ZF.permute(2, 0, 1, 3) / torch.linalg.norm(BS_ZF, dim=[2])
    BS_ZF = BS_ZF.permute(1, 2, 0, 3) * math.sqrt(P / K) # BS_ZF = (R, batch_size, M, K)

    # calculate the power gain
    BS_H_UE = torch.matmul(H, BS_ZF) # BS_H_UE = (R, batch_size, K, K)
    BS_H_UE = torch.abs(BS_H_UE)
    HV = BS_H_UE ** 2

    eff_power = torch.diagonal(HV, offset=0, dim1=-2, dim2=-1)
    sum_power = torch.sum(HV, dim=3)

    # calculate the rate of each UE
    rate_k = (sum_power + sigma) / (sum_power - eff_power + sigma)
    rate_k = torch.log2(rate_k)
    
    # calculate the sum rate
    sum_rate = torch.sum(rate_k, dim = 2)
    mean_sum_rate = torch.mean(sum_rate, dim = 1) #(R,)
    return mean_sum_rate