'''
 @ File: channel_NMSEloss.py
 @ Time: (UTC+8) 2023/08/21 13:07:48
 @ Description: Calculate NMSE loss between predicted channel and ground truth channel. Note that this loss is not used in the current paper, just for future work.
'''
import torch

def channel_NMSEloss(h_label, h_recover, num_RB=8):
    """NMSE loss

    Args:
        h_label (tensor): downlink channel in shape (num_RB, batch_size, num_UE, BS_antenna)
        h_recover (tensor): predicted channel in shape (num_RB, batch_size, num_UE, BS_antenna)
        num_RB (int, optional): RB number. Defaults to 8.

    Returns:
        NMSE (tensor): NMSE loss in shape (num_RB,)  
    """
    h_label = h_label.reshape(h_label.shape[0], 5, num_RB, h_label.shape[2]).permute(2, 0, 1, 3)
    return torch.mean(torch.linalg.norm((h_label-h_recover),dim=(2, 3))**2 / torch.linalg.norm(h_label,dim=(2, 3))**2, dim = 1)