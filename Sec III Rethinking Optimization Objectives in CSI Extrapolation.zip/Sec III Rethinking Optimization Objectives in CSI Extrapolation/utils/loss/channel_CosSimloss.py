'''
 @ File: channel_CosSimloss.py
 @ Time: (UTC+8) 2023/08/21 13:05:09
 @ Description: Calculate cosine similarity loss between predicted channel and ground truth channel. Note that this loss is not used in the current paper, just for future work.
'''
import torch

def channel_CosSimloss(H, V):
    """cosine similarity loss

    Args:
        H (tensor): downlink channel in shape (num_RB, batch_size, num_UE, BS_antenna)
        V (tensor): predicted channel in shape (num_RB, batch_size, num_UE, BS_antenna)

    Returns:
        cos_sim (tensor): cosine similarity loss in shape (num_RB,)
    """
    V_conj = V.conj() # (num_RB, batch_size, num_UE, BS_antenna)
    cos_sim = torch.mean(torch.mean(torch.abs(torch.sum(V_conj * H, dim = 3)) /
                         (torch.linalg.norm(V_conj, dim=[3]) * torch.linalg.norm(H, dim=[3])), dim = 2), dim = 1)  # (num_RB,)

    return cos_sim