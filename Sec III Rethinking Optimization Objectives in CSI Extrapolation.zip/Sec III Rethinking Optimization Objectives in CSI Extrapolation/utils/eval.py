'''
 @ File: eval.py
 @ Time: (UTC+8) 2023/08/21 13:11:07
 @ Description: Evaluate the model.
'''
import torch
from utils.loss.rate_for_multi_UE import rate_for_multi_UE
from utils.loss.channel_CosSimloss import channel_CosSimloss
from utils.loss.channel_NMSEloss import channel_NMSEloss


def eval(model, loader, sigma=2.26e-10):
    """evaluate the model with NMSE loss, rate loss and cosine similarity loss

    Args:
        model (Model): model
        loader (Dataloader): evaluation dataloader
        sigma (float, optional): amplitude of additive gauss noise. Defaults to 2.26e-10.

    Returns:
        NMSE_losses (tensor): average NMSE loss of the model
        rate_losses (tensor): average rate loss of the model
        cossim_losses (tensor): average cosine similarity loss of the model
    """
    model.eval()

    # running loss
    num_RB = 8
    running_NMSE = torch.zeros(num_RB)
    running_rate = torch.zeros(num_RB)
    running_cossim = torch.zeros(num_RB)

    with torch.no_grad():
        for _, channel_load in enumerate(loader):
            # split the CSI into uplink and downlink
            # (batch_size, 5, 32, 8)
            channel_uplink = channel_load[:, :,
                                          :, 0: channel_load.shape[3] // 2]
            channel_downlink = channel_load[:, :, :, channel_load.shape[3] //
                                            2: channel_load.shape[3]].permute(0, 1, 3, 2)  # (batch_size, 5, 8, 32)
            channel_downlink_unnorm = channel_downlink.permute(
                2, 0, 1, 3)  # (8, batch_size, 5, 32)

            # normalize the downlink channel of each UE
            max_channel = torch.amax(torch.abs(channel_downlink.reshape(channel_downlink.shape[0],
                                                                        channel_downlink.shape[1], -1)), dim=2)  # the maximun channel element of each user in shape (batch, 5(num_UE))
            channel_downlink = channel_downlink.permute(0, 1, 3, 2).reshape(
                channel_downlink.shape[0], channel_downlink.shape[1], -1)  # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
            # (8(num_RB)*32(BS antennas), batch, 5(num_UE))
            channel_downlink = channel_downlink.permute(2, 0, 1) / max_channel
            # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
            channel_downlink = channel_downlink.permute(1, 2, 0)
            # (batch, 5(num_UE)*8(num_RB), 32(BS antennas))
            channel_downlink = channel_downlink.reshape(
                channel_downlink.shape[0], channel_downlink.shape[1] * channel_load.shape[3] // 2, channel_load.shape[2])
            channel_downlink_complex = channel_downlink
            # (batch, 2, 5(num_UE)*8(num_RB), 32(BS antennas))
            channel_downlink = torch.stack(
                (channel_downlink.real, channel_downlink.imag), dim=1)

            # pass the uplink channel through the network
            channel_predict = model(channel_uplink)  # (batch, 2, 5*8, 32)

            channel_predict = channel_predict.reshape(
                channel_load.shape[0], 2, channel_load.shape[1], channel_load.shape[3] // 2, channel_load.shape[2]).permute(3, 0, 1, 2, 4)  # (8, batch, 2, 5, 32)
            channel_predict = torch.complex(
                channel_predict[:, :, 0, :, :], channel_predict[:, :, 1, :, :])  # (8, batch, 5, 32)

            loss = channel_NMSEloss(channel_downlink_complex, channel_predict)
            rate = rate_for_multi_UE(
                channel_predict, channel_downlink_unnorm, sigma)
            cos_sim = channel_CosSimloss(
                channel_downlink_unnorm, channel_predict)

            running_NMSE += loss.data.cpu()
            running_rate += rate.data.cpu()
            running_cossim += cos_sim.data.cpu()

    # average loss
    NMSE_losses = running_NMSE / len(loader)
    rate_losses = running_rate / len(loader)
    cossim_losses = running_cossim / len(loader)

    return NMSE_losses, rate_losses, cossim_losses
