'''
 @ File: dataset.py
 @ Time: (UTC+8) 2023/09/26 11:07:26
 @ Description: Loading CSI from MATLAB files and create dataset. MATLAB matrix is in the shape of (num_data, 5(users), 32(BS antennas), 32(RB)) or (num_data, 5, 1, 32, 32). 
                and we split the last dimension to create two pieces of data, i.e. (num_data*2, 5, 32, 16).
'''
from os import listdir
from os.path import isfile, join
import scipy.io as sio
import numpy as np
import torch
from torch.utils.data import Dataset


class CSIDataset(Dataset):
    def __init__(self, path, batch_size=64, device='cuda:0' if torch.cuda.is_available() else 'cpu'):
        """Load CSI data from MATLAB files.

        Args:
            path (str): path to the folder containing MATLAB files.
            batch_size (int, optional): batch size. Defaults to 64.
            device (str, optional): device to store data. Defaults to 'cuda:0' if torch.cuda.is_available() else 'cpu'.
        """
        super().__init__()
        self.batch_size = batch_size
        self.device = device
        self.files = [join(path, f)
                      for f in listdir(path) if isfile(join(path, f))]
        self.data = np.zeros((0, 5, 32, 16))
        for file in self.files:
            mat = sio.loadmat(file)
            csi = np.squeeze(mat['data_set'])
            csi = csi.reshape(
                (csi.shape[0], csi.shape[1], csi.shape[2], 2, 16)).transpose((3, 0, 1, 2, 4)) # split the CSI matrix into two pieces
            csi = csi.reshape((-1, csi.shape[2], csi.shape[3], csi.shape[4]))
            self.data = np.concatenate((self.data, csi), axis=0)

    def __len__(self):
        """Get the number of dataset.

        Returns:
            int: number of samples in the dataset.
        """
        return len(self.data)

    def __getitem__(self, idx):
        """Get the item of the dataset.

        Args:
            idx (int): index of the item.

        Returns:
            torch.Tensor: the idx-th csi data.
        """
        return torch.from_numpy(np.complex64(self.data[idx])).to(self.device)
