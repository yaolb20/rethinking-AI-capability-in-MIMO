%{
 @ File: fig2.m
 @ Time: (UTC+8) 2023/12/14 00:51:23
 @ Description: Run this script to plot Figure 2 in the paper.
%}
clc; clear; close all;

rate1 = [0, 0, 0, 0, 0, 0]; % model-driven
rate2 = [0, 0, 0, 0, 0, 0]; % data-driven
rate3 = [10.92, 16.24, 22.23, 27.75, 32.19, 35.59]; % ZF on noisy CSI
SNR_str = ["0dB", "5dB", "10dB", "15dB", "20dB", "25dB"];

for i = 1:6
    filename = strcat("./records/DNN_", SNR_str(i), ".mat");
    load(filename);
    rate1(i) = -min(loss_eval, [], 'all'); % get the maximum rate
    filename = strcat("./records/DNN2_", SNR_str(i), ".mat");
    load(filename);
    rate2(i) = -min(loss_eval, [], 'all'); % get the maximum rate
end

SNR = 0:5:25;

figure(1);
hold on;
grid on;
box on;
plot(SNR, rate1, '-*b', 'LineWidth', 1.5, 'Color', '#DB4040');
plot(SNR, rate2, '-om', 'LineWidth', 1.5, 'Color', '#49AADB');
plot(SNR, rate3, '--r', 'LineWidth', 1.5, 'Color', '#4A1A9D');
ylim([10, 37]);

xlabel('SNR (dB)');
ylabel('Spectral efficiency (bps/Hz)');
legend('Model-driven', 'Data-driven', 'ZF on noisy CSI', 'Location', 'SouthEast');
