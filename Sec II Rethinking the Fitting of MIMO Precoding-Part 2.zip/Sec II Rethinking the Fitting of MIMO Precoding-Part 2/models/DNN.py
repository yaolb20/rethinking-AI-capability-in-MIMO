'''
 @ File: DNN.py
 @ Time: (UTC+8) 2023/11/03 15:23:19
 @ Description: The model-driven DNN model to perform precoding.
'''
import torch
import torch.nn as nn
import torch.nn.functional as F
import models.basemodel as basemodel


class DNN(basemodel.BaseModel):
    def __init__(self, M, N):
        '''Initialize the model

        Args:
            M (int): BS antenna number
            N (int): UE number
        '''

        super(DNN, self).__init__()
        self.M = M
        self.N = N
        self.fc1 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm1 = nn.BatchNorm1d(2 * M * N)
        self.dropout1 = nn.Dropout(0.02)
        self.fc2 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm2 = nn.BatchNorm1d(2 * M * N)
        self.dropout2 = nn.Dropout(0.02)
        self.fc3 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm3 = nn.BatchNorm1d(2 * M * N)
        self.dropout3 = nn.Dropout(0.02)
        self.fc4 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm4 = nn.BatchNorm1d(2 * M * N)
        self.dropout4 = nn.Dropout(0.02)
        self.fc5 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm5 = nn.BatchNorm1d(2 * M * N)
        self.dropout5 = nn.Dropout(0.02)
        self.fc6 = nn.Linear(2 * M * N, 2 * M * N)

    def forward(self, x):
        '''Forward propagation

        Args:
            x (torch.Tensor): complex tensor with shape (batch_size, N, M)

        Returns:
            torch.Tensor: complex tensor with shape (batch_size, M, N)
        '''
        # reshape the input matrices to vectors
        x0 = torch.stack((x.real, x.imag), dim=-1)
        x0 = x0.view(-1, 2 * self.N * self.M).to(dtype=torch.float32)
        # 2 FC layers with residual connections
        x1 = self.fc1(x0)
        x1 = self.batchnorm1(x1)
        x1 = self.dropout1(x1)
        x1 = F.leaky_relu(x1)
        x1 = self.fc2(x1)
        x1 = self.batchnorm2(x1)
        x1 = self.dropout2(x1)
        x1 = F.leaky_relu(x1)
        x2 = x1 + x0
        # 2 FC layers with residual connections
        x2 = self.fc3(x2)
        x2 = self.batchnorm3(x2)
        x2 = self.dropout3(x2)
        x2 = F.leaky_relu(x2)
        x2 = self.fc4(x2)
        x2 = self.batchnorm4(x2)
        x2 = self.dropout4(x2)
        x2 = F.leaky_relu(x2)
        x3 = x2 + x1 + x0
        # 2 FC layers with residual connections
        x3 = self.fc5(x3)
        x3 = self.batchnorm5(x3)
        x3 = self.dropout5(x3)
        x3 = F.leaky_relu(x3)
        out = self.fc6(x3)
        out = out + x2 + x1 + x0
        # reshape the output vectors to matrices
        out = out.view(-1, self.N, self.M, 2)
        out = torch.complex(out[..., 0], out[..., 1])
        # apply ZF precoding
        out = torch.linalg.pinv(out)
        return out
