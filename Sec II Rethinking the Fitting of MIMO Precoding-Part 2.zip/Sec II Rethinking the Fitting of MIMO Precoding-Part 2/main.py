'''
 @ File: main.py
 @ Time: (UTC+8) 2023/11/03 16:50:53
 @ Description: Train the model and save the records, the model could be changed by modifying Line 12, and the SNR could be changed by modifying Line 28.
'''
import torch
import torch.optim as optim
import numpy as np
import scipy.io as sio
from utils.dataset import ChannelDataset
from torch.utils.data import DataLoader
from models.DNN2 import DNN
from utils.train import train
from utils.eval import eval


def main(training_time=3, epoch_num=300, batch_size=64, lr=1e-3, device='cuda:0' if torch.cuda.is_available() else 'cpu'):
    """The main function of the project

    Args:
        training_time (int, optional): number of training times. Defaults to 3.
        epoch_num (int, optional): number of epochs. Defaults to 300.
        batch_size (int, optional): batch size. Defaults to 64.
        lr (float, optional): learning rate. Defaults to 1e-3.
        device (str, optional): device to load data. Defaults to 'cuda:0' if torch.cuda.is_available() else 'cpu'.
    """

    SNR = '10dB'
    name = 'DNN2_'+SNR
    print('Model: %s' % name)
    print('Training time: %d' % training_time)
    print('Epoch number: %d' % epoch_num)
    print('Batch size: %d' % batch_size)
    print('Learning rate: %e' % lr)
    print('Device: %s' % device)
    print('SNR: %s' % SNR)
    print('----------------------------------------')

    train_dataset = ChannelDataset(
        'data/train_'+SNR+'/', device)
    eval_dataset = ChannelDataset(
        'data/eval_'+SNR+'/', device)

    train_loader = DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True)
    eval_loader = DataLoader(
        eval_dataset, batch_size=batch_size, shuffle=False)

    loss_train = np.zeros((training_time, epoch_num))
    loss_eval = np.zeros((training_time, epoch_num))

    for idx in range(training_time):
        print('Training time: %d' % (idx + 1))

        model = DNN(M=32, N=5).to(device)
        optimizer = optim.Adam(model.parameters(), lr=lr)

        for epoch in range(epoch_num):
            loss_train[idx, epoch] = train(
                model, train_loader, optimizer)
            loss_eval[idx, epoch] = eval(model, eval_loader)

            print('Epoch: %d, Training loss: %.2f, Evaluation loss: %.2f' %
                  (epoch + 1, loss_train[idx, epoch], loss_eval[idx, epoch]))
            if (epoch+1) % 5 == 0:
                checkpoint = {
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'epoch': epoch
                }
                torch.save(checkpoint, './checkpoints/%s_checkpoint.pt' % name)

            sio.savemat('./records/%s.mat' % name, {'loss_train': loss_train,
                                                    'loss_eval': loss_eval})


if __name__ == "__main__":
    main()
