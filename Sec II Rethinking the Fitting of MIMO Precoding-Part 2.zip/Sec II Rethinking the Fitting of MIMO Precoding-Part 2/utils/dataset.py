'''
 @ File: dataset.py
 @ Time: (UTC+8) 2023/12/11 21:46:26
 @ Description: Read data from .npy files and create a dataset
'''
from os import listdir
from os.path import isfile, join
import scipy.io as sio
import numpy as np
import torch
from torch.utils.data import Dataset


class ChannelDataset(Dataset):
    def __init__(self, path, device='cuda:0' if torch.cuda.is_available() else 'cpu'):
        """Read data from .npy files

        Args:
            path (str): path to the folder containing MATLAB files.
            device (str, optional): device to load data. Defaults to 'cuda:0'if torch.cuda.is_available() else 'cpu'.
        """
        super(ChannelDataset, self).__init__()
        self.device = device
        self.files = [join(path, f)
                      for f in listdir(path) if isfile(join(path, f))]
        self.channel = np.zeros((0, 5, 32), dtype=np.complex64)
        self.channel_noise = np.zeros((0, 5, 32), dtype=np.complex64)
        for file in self.files:
            data = sio.loadmat(file)
            data_set = data['data_set']
            data_set_input = data['data_set_input']
            self.channel = np.concatenate(
                (self.channel, data_set), axis=0)
            self.channel_noise = np.concatenate(
                (self.channel_noise, data_set_input), axis=0)

    def __len__(self):
        """Get the length of dataset

        Returns:
            int: number of samples in the dataset.
        """
        return len(self.channel)

    def __getitem__(self, idx):
        """Get a sample from dataset

        Args:
            idx (int): index of sample

        Returns:
            torch.Tensor: complex tensor with shape (N, M)
            torch.Tensor: complex tensor with shape (N, M)
        """
        channel = self.channel[idx]
        channel_noise = self.channel_noise[idx]
        return torch.from_numpy(channel).to(self.device).to(torch.complex64), torch.from_numpy(channel_noise).to(self.device).to(torch.complex64)
