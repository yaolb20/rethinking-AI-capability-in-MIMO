'''
 @ File: DNN10.py
 @ Time: (UTC+8) 2023/11/03 15:23:19
 @ Description: The DNN model with 10 FC layer to fit the CSI matrix inversion operation
'''
import torch
import torch.nn as nn
import torch.nn.functional as F
import models.basemodel as basemodel


class DNN10(basemodel.BaseModel):
    def __init__(self, M, N):
        '''Initialize the model

        Args:
            M (int): row number of matrix
            N (int): column number of matrix
        '''

        super(DNN10, self).__init__()
        self.M = M
        self.N = N
        self.fc1 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm1 = nn.BatchNorm1d(2 * M * N)
        self.dropout1 = nn.Dropout(0.02)
        self.fc2 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm2 = nn.BatchNorm1d(2 * M * N)
        self.dropout2 = nn.Dropout(0.02)
        self.fc3 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm3 = nn.BatchNorm1d(2 * M * N)
        self.dropout3 = nn.Dropout(0.02)
        self.fc4 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm4 = nn.BatchNorm1d(2 * M * N)
        self.dropout4 = nn.Dropout(0.02)
        self.fc5 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm5 = nn.BatchNorm1d(2 * M * N)
        self.dropout5 = nn.Dropout(0.02)
        self.fc6 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm6 = nn.BatchNorm1d(2 * M * N)
        self.dropout6 = nn.Dropout(0.02)
        self.fc7 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm7 = nn.BatchNorm1d(2 * M * N)
        self.dropout7 = nn.Dropout(0.02)
        self.fc8 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm8 = nn.BatchNorm1d(2 * M * N)
        self.dropout8 = nn.Dropout(0.02)
        self.fc9 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm9 = nn.BatchNorm1d(2 * M * N)
        self.dropout9 = nn.Dropout(0.02)
        self.fc10 = nn.Linear(2 * M * N, 2 * M * N)

    def forward(self, x):
        '''Forward propagation

        Args:
            x (torch.Tensor): complex tensor with shape (batch_size, M, N)

        Returns:
            torch.Tensor: complex tensor with shape (batch_size, M, N)
        '''
        # reshape the input matrices to vectors
        x0 = torch.stack((x.real, x.imag), dim=-1)
        x0 = x0.view(-1, 2 * self.M * self.N).to(dtype=torch.float32)
        # 2 FC layers with residual connection
        x1 = self.fc1(x0)
        x1 = self.batchnorm1(x1)
        x1 = self.dropout1(x1)
        x1 = F.leaky_relu(x1, negative_slope=0.01)
        x1 = self.fc2(x1)
        x1 = self.batchnorm2(x1)
        x1 = self.dropout2(x1)
        x1 = F.leaky_relu(x1, negative_slope=0.01)
        x2 = x1 + x0
        # 2 FC layers with residual connection
        x2 = self.fc3(x2)
        x2 = self.batchnorm3(x2)
        x2 = self.dropout3(x2)
        x2 = F.leaky_relu(x2, negative_slope=0.01)
        x2 = self.fc4(x2)
        x2 = self.batchnorm4(x2)
        x2 = self.dropout4(x2)
        x2 = F.leaky_relu(x2, negative_slope=0.01)
        x3 = x2 + x1 + x0
        # 2 FC layers with residual connection
        x3 = self.fc5(x3)
        x3 = self.batchnorm5(x3)
        x3 = self.dropout5(x3)
        x3 = F.leaky_relu(x3, negative_slope=0.01)
        x3 = self.fc6(x3)
        x3 = self.batchnorm6(x3)
        x3 = self.dropout6(x3)
        x3 = F.leaky_relu(x3, negative_slope=0.01)
        x4 = x3 + x2 + x1 + x0
        # 2 FC layers with residual connection
        x4 = self.fc7(x4)
        x4 = self.batchnorm7(x4)
        x4 = self.dropout7(x4)
        x4 = F.leaky_relu(x4, negative_slope=0.01)
        x4 = self.fc8(x4)
        x4 = self.batchnorm8(x4)
        x4 = self.dropout8(x4)
        x4 = F.leaky_relu(x4, negative_slope=0.01)
        x5 = x4 + x3 + x2 + x1 + x0
        # 2 FC layers with residual connection
        x5 = self.fc9(x5)
        x5 = self.batchnorm9(x5)
        x5 = self.dropout9(x5)
        x5 = F.leaky_relu(x5, negative_slope=0.01)
        out = self.fc10(x5)
        out = out + x4 + x3 + x2 + x1 + x0
        # reshape the output vectors to matrices
        out = out.view(-1, self.M, self.N, 2)
        out = torch.complex(out[..., 0], out[..., 1])

        return out
