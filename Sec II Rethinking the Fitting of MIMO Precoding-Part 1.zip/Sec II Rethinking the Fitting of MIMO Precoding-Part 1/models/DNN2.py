'''
 @ File: DNN2.py
 @ Time: (UTC+8) 2023/11/03 15:23:19
 @ Description: The DNN model with 2 FC layer to fit the CSI matrix inversion operation
'''
import torch
import torch.nn as nn
import torch.nn.functional as F
import models.basemodel as basemodel


class DNN2(basemodel.BaseModel):
    def __init__(self, M, N):
        '''Initialize the model

        Args:
            M (int): row number of matrix
            N (int): column number of matrix
        '''

        super(DNN2, self).__init__()
        self.M = M
        self.N = N
        self.fc1 = nn.Linear(2 * M * N, 2 * M * N)
        self.batchnorm1 = nn.BatchNorm1d(2 * M * N)
        self.dropout1 = nn.Dropout(0.02)
        self.fc2 = nn.Linear(2 * M * N, 2 * M * N)

    def forward(self, x):
        '''Forward propagation

        Args:
            x (torch.Tensor): complex tensor with shape (batch_size, M, N)

        Returns:
            torch.Tensor: complex tensor with shape (batch_size, M, N)
        '''
        # reshape the input matrices to vectors
        x1 = torch.stack((x.real, x.imag), dim=-1)
        x1 = x1.view(-1, 2 * self.M * self.N).to(dtype=torch.float32)
        # 2 FC layers
        x1 = self.fc1(x1)
        x1 = self.batchnorm1(x1)
        x1 = self.dropout1(x1)
        x1 = F.leaky_relu(x1, negative_slope=0.01)
        out = self.fc2(x1)
        # reshape the output vectors to matrices and add residual connection
        out = out.view(-1, self.M, self.N, 2)
        out = torch.complex(out[..., 0], out[..., 1]) + x

        return out
