'''
 @ File: train.py
 @ Time: (UTC+8) 2023/11/03 16:39:07
 @ Description: Train the model for one epoch
'''
from utils.inv_loss import inv_loss


def train(model, train_loader, optimizer):
    """Train the model for one epoch

    Args:
        model (torch.nn.Module): the DNN model
        train_loader (torch.utils.data.DataLoader): data loader for training
        optimizer (torch.optim): optimizer

    Returns:
        float: average loss
    """

    model.train()
    running_loss = 0
    for _, (channel, _) in enumerate(train_loader):
        optimizer.zero_grad()
        output = model(channel)
        loss = inv_loss(channel, output)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
    return running_loss / len(train_loader)
