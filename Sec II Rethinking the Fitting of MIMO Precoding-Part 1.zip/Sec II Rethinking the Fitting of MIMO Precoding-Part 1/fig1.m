%{
 @ File: fig1.m
 @ Time: (UTC+8) 2023/12/14 12:50:49
 @ Description: Run this script to generate Fig. 1 in the paper.
%}

clc; clear; close all;

layers = ["2", "6", "10"];
conds = ["1", "sqrt10", "10", "10sqrt10", "100", "100sqrt10", "1000"];

mse = zeros(length(layers), length(conds));

% Load the records from the files
for i = 1:length(layers)

    for j = 1:length(conds)
        filename = strcat("./records/DNN", layers(i), "_cond", conds(j), ".mat");
        load(filename);
        mse(i, j) = min(loss_eval, [], 'all');
    end

end

figure(1);
hold on;
grid on;
box on;
plot([1, sqrt(10), 10, 10 * sqrt(10), 100, 100 * sqrt(10), 1000], mse(1, :), '-x', 'LineWidth', 1.5, 'Color', '#49AADB');
plot([1, sqrt(10), 10, 10 * sqrt(10), 100, 100 * sqrt(10), 1000], mse(2, :), '-*', 'LineWidth', 1.5, 'Color', '#DB4040');
plot([1, sqrt(10), 10, 10 * sqrt(10), 100, 100 * sqrt(10), 1000], mse(3, :), 'k-o', 'LineWidth', 1.5, 'Color', '#25BB29');
xlabel('Condition number');
ylabel('MSE');
legend('2 Layers', '6 Layers', '10 Layers', 'Location', 'southeast');
set(gca, 'xScale', 'log');
ylim([0, 2.2]);
