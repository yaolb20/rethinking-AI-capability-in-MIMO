function [Space_vec] = Space_basis(M, N)
B = zeros(M*N, M*N);
for i = 0 : M - 1
    base1 = exp(1i * 2 * pi / M * i * (0 : M - 1));
    for j = 0 : N - 1
        base2 = exp(1i * 2 * pi / N * j * (0 : N - 1));
        B(i * N + j + 1, :) = reshape(base1.' * base2, [M*N, 1]);
    end
end
Space_vec = [B,zeros(M*N, M*N); zeros(M*N,M*N), B];
end