clc;
clear;
data_set = []; % DL CSI
feedback_vector_set = []; % feedback CSI vector
beam_index_set = []; % selected angular-domain index
delay_index_set = []; % selected delay-domain index
load_Path = 'test_noisefree\';
filenum = 20;
batch_num = 256 * filenum; % number of overall batch: 256 * number of files

for ite = 1 : 20
    load([load_Path, 'dataset_', num2str(ite), '.mat']);
    data_set = [data_set; EVCSI_matrix_origin];
    feedback_vector_set = [feedback_vector_set; Feedback_DL];
    beam_index_set = [beam_index_set; beam_index];
    delay_index_set = [delay_index_set; delay_index];
    ite
end

% Equal power allocation on single RB
RB_num = 16; % number of DL RB
RB_pergroup = RB_num;
M = 4;
N = 4;
tx_num = M * N * 2; % BS antenna number, M, N for dual-polarized UPA
UE_num = 5; % UE number
Space_vec = Space_basis(M, N); % CSI transformation basis
time_slot = 1;
CSI_RS_rec = [32]; % selected port number
P_dB = 43; % transmit power
size_rs = size(CSI_RS_rec);
size_p = 1;
res = zeros(size_rs(2), size_p(2));
res_perfect = zeros(size_rs(2), size_p(2));
noise = 10^(-169 / 10 - 3) * 180 * 10^3; % noise power
for rs = 1 : size_rs(2)
    CSI_RS = CSI_RS_rec(rs);
    for p = 1 : size_p(2)
        P = 10^(P_dB / 10 - 3) / 100 / UE_num;
        for i = 1 : batch_num
            for time = 1 : time_slot
                time_temp = floor((time - 1) / 4) + 1;
                W = zeros(UE_num, tx_num, RB_pergroup);
                W_perfect = zeros(UE_num, tx_num, RB_pergroup);
                H_DL = squeeze(data_set(i, :, :, 1 : RB_pergroup));

                % type II codebook
                for j = 1 : UE_num
                    [W_perfect(j, :, :), W(j, :, :)] = Type_II_codebook(squeeze(H_DL(j, :, :)), ...
                        squeeze(feedback_vector_set(i, j, :)), squeeze(beam_index_set(i, j, :)), squeeze(delay_index_set(i, j, :)), ...
                        4, tx_num, CSI_RS, RB_pergroup, Space_vec);
                end

                % beamforming gain calculation
                W_zf = zeros(tx_num, UE_num, RB_pergroup);
                W_zf_perfect = zeros(tx_num, UE_num, RB_pergroup);
                for j = 1 : RB_pergroup
                    H_eq = (W(:,:, j)').';
                    H_eq_perfect = (W_perfect(:,:,j)').';
                    W_zf(:, :, j) = pinv(H_eq);
                    W_zf_perfect(:, :, j) = pinv(H_eq_perfect);
                    W_zf(:, :, j) = W_zf(:, :, j) ./ sqrt(sum(abs(W_zf(:, :, j)).^2, 1)); %% normalization
                    W_zf_perfect(:, :, j) = W_zf_perfect(:, :, j) ./ sqrt(sum(abs(W_zf_perfect(:, :, j)).^2, 1)); %% normalization
                end
                bf_gain = zeros(UE_num, UE_num, RB_pergroup);
                bf_gain_perfect = zeros(UE_num,UE_num,RB_pergroup);
                for j = 1 : UE_num
                    for l = 1 : RB_pergroup
                        bf_gain(j, :, l) = squeeze(H_DL(j, :, l)) * W_zf(:, :, l);
                        bf_gain_perfect(j, :, l) = squeeze(H_DL(j, :, l)) * W_zf_perfect(:, :, l);
                    end
                end
                bf_gain = abs(bf_gain).^2;
                bf_gain_perfect = abs(bf_gain_perfect).^2;

                % rate calculation
                for j = 1 : UE_num
                    for l = 1 : RB_pergroup
                        res(rs, p)  = res(rs, p) + log2(1 + P * bf_gain(j, j, l)/ (P * (sum(bf_gain(j, :, l)) - bf_gain(j, j, l)) + noise));
                        res_perfect(rs, p) = res_perfect(rs, p) + log2(1 + P * bf_gain_perfect(j, j, l)/ (P * (sum(bf_gain_perfect(j, :, l)) - bf_gain_perfect(j, j, l)) + noise));
                    end
                end
            end
        end
        res(rs, p) = res(rs, p) / RB_pergroup / batch_num / time_slot; % feedback with quantization
        res_perfect(rs, p) = res_perfect(rs, p) / RB_pergroup / batch_num / time_slot; % feedback with perfect quantization
        [rs, p] % show results
    end
end