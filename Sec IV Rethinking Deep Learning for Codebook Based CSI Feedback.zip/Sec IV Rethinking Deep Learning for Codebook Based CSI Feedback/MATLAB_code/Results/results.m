clear all;
close all;
clc



res1 = [];
load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B209,index_B20,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=5dB).mat');
res1 = [res1 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B209,index_B20,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=15dB).mat');
res1 = [res1 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B209,index_B20,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=25dB).mat');
res1 = [res1 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B209,index_B20,mu0.00025,weight_sum1.0000,lr0.00100,epoch200).mat');
res1 = [res1 max(max(squeeze(loss_eval(2, :, :))))]



res2 = [];
load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B219,index_B10,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=5dB).mat');
res2 = [res2 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B219,index_B10,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=15dB).mat');
res2 = [res2 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B219,index_B10,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=25dB).mat');
res2 = [res2 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v2(UL_CSI_Input(zp,amp),All_Filled_Output)(M16,B219,index_B10,mu0.00025,weight_sum1.0000,lr0.00100,epoch200).mat');
res2 = [res2 max(max(squeeze(loss_eval(2, :, :))))]


res3 = [];
load('OriginalCsiNet_v1(Vector_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=5dB).mat');
res3 = [res3 max(max(squeeze(loss_eval(2, :, :))))];

load('OriginalCsiNet_v1(Vector_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=15dB).mat');
res3 = [res3 max(max(squeeze(loss_eval(2, :, :))))];

load('OriginalCsiNet_v1(Vector_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=25dB).mat');
res3 = [res3 max(max(squeeze(loss_eval(2, :, :))))];

load('OriginalCsiNet_v1(Vector_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200).mat');
res3 = [res3 max(max(squeeze(loss_eval(2, :, :))))]


res4 = [];
load('DualCsiNet_v1(All_Filled_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=5dB).mat');
res4 = [res4 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v1(All_Filled_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=15dB).mat');
res4 = [res4 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v1(All_Filled_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200,SNR=25dB).mat');
res4 = [res4 max(max(squeeze(loss_eval(2, :, :))))];

load('DualCsiNet_v1(All_Filled_Output)(M16,B229,mu0.00025,weight_sum1.0000,lr0.00100,epoch200).mat');
res4 = [res4 max(max(squeeze(loss_eval(2, :, :))))]