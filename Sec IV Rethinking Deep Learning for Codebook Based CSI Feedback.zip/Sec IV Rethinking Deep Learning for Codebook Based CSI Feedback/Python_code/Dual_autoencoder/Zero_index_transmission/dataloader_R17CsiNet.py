from os import listdir
from os.path import isfile, join
import scipy.io as sio
import numpy as np
import torch


class Dataloader():
    def __init__(self, path = '', b = 32, K = 5, N_t = 32, N_p = 32, M = 8, device = 'cpu'):
        
        self.b = b 
        self.K = K
        self.N_t  = N_t
        self.N_p  = N_p
        self.M  = M 
        self.device = device
        # count file names
        self.files = [
            join(path, f) for f in listdir(path) if isfile(join(path, f))
        ]
        for i, f in enumerate(self.files):
            if not f.split('.')[-1] == 'mat':
                del (self.files[i])
        self.reset()

    # reset buffers
    def reset(self):
        self.unvisited_files = [f for f in self.files]
        self.buffer_basis_angle = np.zeros((0, self.K, self.N_t, self.N_p)) 
        self.buffer_basis_delay = np.zeros((0, self.K, self.N_p, self.M)) 
        self.buffer_Feedback_DL = np.zeros((0, self.K, self.N_p)) 
        self.buffer_EVCSI_matrix_origin = np.zeros((0, self.K, self.N_t, self.M))
        self.buffer_label_zp_DL = np.zeros((0, self.K, self.N_t, self.M))
        self.buffer_label_op_DL = np.zeros((0, self.K, self.N_t, self.M))
        # from MATLAB to Python
        self.buffer_beam_index = np.zeros((0, self.K, self.N_p)) - 1
        self.buffer_delay_index = np.zeros((0, self.K, self.N_p)) - 1
            
    def load(self, file):
        data = sio.loadmat(file)
        basis_angle = data['basis_angle'] # angular port index
        basis_delay = data['basis_delay'] # delay port index
        Feedback_DL = data['Feedback_DL'] # feedback CSI vector
        EVCSI_matrix_origin = data['EVCSI_matrix_origin'] # original DL CSI
        label_zp_DL = data['label_zp_DL'] # DL CSI normalized label (unselected port filled with 0)
        label_op_DL = data['label_op_DL'] # DL CSI normalized label
        # from MATLAB to Python
        beam_index = data['beam_index'] - 1
        delay_index = data['delay_index'] - 1
        return basis_angle, basis_delay, Feedback_DL, EVCSI_matrix_origin, label_zp_DL, label_op_DL, beam_index, delay_index

    def next_batch(self):
        # serially load data
        done = False
        while self.buffer_Feedback_DL.shape[0] < self.b:
            # if finishing load data
            if len(self.unvisited_files) == 0:
                done = True
                break
            basis_angle, basis_delay, Feedback_DL, EVCSI_matrix_origin, label_zp_DL, label_op_DL, beam_index, delay_index = self.load(self.unvisited_files.pop(0))

            # load data into buffers            
            self.buffer_basis_angle = np.concatenate((self.buffer_basis_angle, basis_angle), axis = 0)
            self.buffer_basis_delay = np.concatenate((self.buffer_basis_delay, basis_delay), axis = 0)
            self.buffer_Feedback_DL = np.concatenate((self.buffer_Feedback_DL, Feedback_DL), axis = 0)
            self.buffer_EVCSI_matrix_origin = np.concatenate((self.buffer_EVCSI_matrix_origin, EVCSI_matrix_origin), axis = 0)
            self.buffer_label_zp_DL = np.concatenate((self.buffer_label_zp_DL, label_zp_DL), axis = 0)
            self.buffer_label_op_DL = np.concatenate((self.buffer_label_op_DL, label_op_DL), axis = 0)
            self.buffer_beam_index = np.concatenate((self.buffer_beam_index, beam_index), axis = 0)
            self.buffer_delay_index = np.concatenate((self.buffer_delay_index, delay_index), axis = 0)
     
        # get data from buffers
        out_size = min(self.b, self.buffer_Feedback_DL.shape[0])
        batch_basis_angle = self.buffer_basis_angle[0 : out_size, :, :, :]
        batch_basis_delay = self.buffer_basis_delay[0 : out_size, :, :, :]
        batch_Feedback_DL = self.buffer_Feedback_DL[0 : out_size, :, :]
        batch_EVCSI_matrix_origin = self.buffer_EVCSI_matrix_origin[0 : out_size, :, :, :]
        batch_label_zp_DL = self.buffer_label_zp_DL[0 : out_size, :, :, :]
        batch_label_op_DL = self.buffer_label_op_DL[0 : out_size, :, :, :]
        batch_beam_index = self.buffer_beam_index[0 : out_size, :, :]
        batch_delay_index = self.buffer_delay_index[0 : out_size, :, :]
        
        self.buffer_basis_angle = np.delete(self.buffer_basis_angle, np.s_[0 : out_size], 0)
        self.buffer_basis_delay = np.delete(self.buffer_basis_delay, np.s_[0 : out_size], 0)
        self.buffer_Feedback_DL = np.delete(self.buffer_Feedback_DL, np.s_[0 : out_size], 0)      
        self.buffer_EVCSI_matrix_origin = np.delete(self.buffer_EVCSI_matrix_origin, np.s_[0 : out_size], 0)
        self.buffer_label_zp_DL = np.delete(self.buffer_label_zp_DL, np.s_[0 : out_size], 0)
        self.buffer_label_op_DL = np.delete(self.buffer_label_op_DL, np.s_[0 : out_size], 0)
        self.buffer_beam_index = np.delete(self.buffer_beam_index, np.s_[0 : out_size], 0)      
        self.buffer_delay_index = np.delete(self.buffer_delay_index, np.s_[0 : out_size], 0)      

        # format transformation for reducing overhead
        batch_basis_angle = np.complex64(batch_basis_angle)
        batch_basis_delay = np.complex64(batch_basis_delay)
        batch_Feedback_DL = np.complex64(batch_Feedback_DL)
        batch_EVCSI_matrix_origin = np.complex64(batch_EVCSI_matrix_origin)
        batch_label_zp_DL = np.complex64(batch_label_zp_DL)
        batch_label_op_DL = np.complex64(batch_label_op_DL)
        batch_beam_index = np.int64(batch_beam_index)
        batch_delay_index = np.int64(batch_delay_index)

        # return data
        return torch.from_numpy(batch_basis_angle).to(self.device), \
            torch.from_numpy(batch_basis_delay).to(self.device), \
            torch.from_numpy(batch_Feedback_DL).to(self.device), \
            torch.from_numpy(batch_EVCSI_matrix_origin).to(self.device), \
            torch.from_numpy(batch_label_zp_DL).to(self.device), \
            torch.from_numpy(batch_label_op_DL).to(self.device), \
            torch.from_numpy(batch_beam_index).to(self.device), \
            torch.from_numpy(batch_delay_index).to(self.device), \
            done

