import torch
import torch.nn as nn
import math
import random
import collections

alpha = 5.

# stacked sigmoid approximation
class Sigmoid_Approximation(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        ctx.save_for_backward(x)
        return 0.25 * (torch.sign(x) + torch.sign(x - 0.5) + torch.sign(x + 0.5))

    @staticmethod
    def backward(ctx, grad_output):
        x = ctx.saved_tensors
        x = x[0]
        global alpha
        grad1 = 0.5 * alpha * torch.sigmoid(
            alpha * x) * (1 - torch.sigmoid(alpha * x)) * grad_output
        grad2 = 0.5 * alpha * torch.sigmoid(
            alpha * (x - 0.5)) * (1 - torch.sigmoid(alpha * (x - 0.5))) * grad_output
        grad3 = 0.5 * alpha * torch.sigmoid(
            alpha * (x + 0.5)) * (1 - torch.sigmoid(alpha * (x + 0.5))) * grad_output
        grad_x = grad1 + grad2 + grad3
        return grad_x, None

# convolution module
class CB2D(nn.Module):
    def __init__(self, f_i = 128, f_o = 128, k = (3, 3), s = (1, 1), p = (1, 1)):
        super(CB2D, self).__init__()
        self.conv = nn.Conv2d(in_channels = f_i, out_channels = f_o, kernel_size = k, stride = s, padding = p, padding_mode = 'circular')
        self.bn = nn.BatchNorm2d(f_o)
        self.activation = nn.LeakyReLU(.1)

    def forward(self, h):
        h = self.conv(h)
        h = self.bn(h)
        h = self.activation(h)
        return h

# main model
class Model(nn.Module):
    def __init__(self,
                 b = 64, # batch size
                 K = 5, # UE number
                 N_t = 32, # BS antenna number
                 N_p = 32, # selected port number
                 M = 8, # RB number
                 B = 209, # feedback bit
                 index_B = 20, # bit for downlink index transmission
                 device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")):
        super(Model, self).__init__()

        # system parameters
        self.b = b
        self.K = K
        self.N_t = N_t
        self.N_p = N_p
        self.M = M  
        self.B = B
        self.index_B = index_B
        self.Q = 2  # number of quantization bits
        self.index_feature_len = 64
        self.device = device
       
        self.qua = Sigmoid_Approximation()

        # Encoding module of standard auto-encoder
        # FCB1
        self.fc_en1 = nn.Linear(2 * self.N_p + self.index_feature_len, 1024)
        self.bn_en1 = nn.BatchNorm1d(1024)
        self.activation_en1 = nn.LeakyReLU(.3)
        
        # FCB2
        self.fc_en2 = nn.Linear(1024, int(self.B/self.Q))
        self.bn_en2 = nn.BatchNorm1d(int(self.B/self.Q))        
        self.activation_en2 = nn.Tanh()

        # Decoding module of standard auto-encoder
        # FCB
        self.drop_de = nn.Dropout(0.02)
        self.fc_de = nn.Linear(int(self.B/self.Q), 2 * self.N_p) 

        # CNN for residual learning
        self.cb1 = CB2D(f_i = 2, f_o = 256, k = (3, 3), s = (1, 1), p = (1, 1))
        self.cb2 = CB2D(f_i = 256, f_o = 512, k = (3, 3), s = (3, 1), p = (1, 1))
        self.cb3 = CB2D(f_i = 512, f_o = 512, k = (3, 3), s = (3, 3), p = (1, 1))
        self.cb4 = CB2D(f_i = 512, f_o = 512, k = (3, 3), s = (3, 3), p = (1, 1))
        self.cb5 = CB2D(f_i = 512, f_o = 512, k = (3, 3), s = (3, 3), p = (1, 1))

        self.drop_out = nn.Dropout(0.02)
        self.fc_out = nn.Linear(512, 2 * self.N_t * self.M)

        # Encoding module of dual auto-encoder
        self.cb_d1_BS = CB2D(f_i=1, f_o=128, k=(3, 3), s=(3, 3), p=(1, 1))
        self.cb_d2_BS = CB2D(f_i=128, f_o=256, k=(3, 3), s=(3, 3), p=(1, 1))
        self.cb_d3_BS = CB2D(f_i=256, f_o=256, k=(3, 3), s=(3, 3), p=(1, 1))
        self.drop_d_BS = nn.Dropout(0.02)
        self.fc_d_BS = nn.Linear(256, int(self.index_B / self.Q))
        self.activation_d_BS = nn.Tanh()

        # Dncoding module of dual auto-encoder
        self.drop_d_UE = nn.Dropout(0.02)
        self.fc_d_UE = nn.Linear(int(self.index_B / self.Q), self.index_feature_len)
        
    def forward(self, h, beam_index, delay_index, weight_sum, h_UL):

        # BS-side dual auto-encoder

        ### Another idea to define UL index: 1/0 encoding, also can achieve gains
        # index = torch.zeros((self.b * self.K * self.N_t, self.M), device=self.device)
        # index[beam_index.detach(), delay_index.detach()] = 1 # (b * K, N_t, M)
        # index = index.reshape(-1, self.N_t, self.M).unsqueeze(1) # (b * K, 1, N_t, M), index input
        # index = self.cb_d1_BS(index)

        index = self.cb_d1_BS(h_UL)

        index = self.cb_d2_BS(index)
        index = self.cb_d3_BS(index)
        index = nn.AvgPool2d(kernel_size=(index.shape[2], index.shape[3]))(index)
        index = self.drop_d_BS(index.squeeze())
        index = self.fc_d_BS(index)
        index = self.activation_d_BS(index)

        index = self.qua.apply(index)

        # UE-side dual auto-encoder
        index = self.drop_d_UE(index)
        index = self.fc_d_UE(index)

        # CSI-index concatenattion
        h = torch.cat((h, index), dim = 1)

        # UE-side standard auto-encoder
        # FCB1
        h = self.fc_en1(h)
        h = self.bn_en1(h)
        h = self.activation_en1(h)
        
        # FCB2
        h = self.fc_en2(h)
        h = self.bn_en2(h)        
        h = self.activation_en2(h)
        
        # uniform quantization
        h = self.qua.apply(h) # Q bit quantization
        
        # BS-side standard auto-encoder
        
        # FCB
        h_recover = self.drop_de(h)
        h_recover = self.fc_de(h_recover)
        # (b * K, 2 * N_p)
              
        # 2-norm
        h_recover_2 = torch.linalg.norm(h_recover, dim = 1)  # (b * K)
        h_recover = h_recover.permute(1, 0) / h_recover_2
        h_recover = h_recover.permute(1, 0) # (b * K, 2 * N_p)
        
        # filling
        h_recover = h_recover.reshape(h_recover.shape[0], 2, self.N_p) # (b * K, 2, N_p)
        h_recover_r = h_recover[:, 0, :]
        h_recover_i = h_recover[:, 1, :]       
        # (b * K, N_p)
        
        h_recover_r = h_recover_r.reshape(-1)
        h_recover_i = h_recover_i.reshape(-1)
        # (b * K * N_p)
        
        H_recover_r = torch.zeros((self.b * self.K * self.N_t, self.M), device = self.device)
        H_recover_i = torch.zeros((self.b * self.K * self.N_t, self.M), device = self.device)
        # (b * K * N_t, M)
        
        H_recover_r[beam_index.detach(), delay_index.detach()] = h_recover_r
        H_recover_i[beam_index.detach(), delay_index.detach()] = h_recover_i
        
        H_recover_r = H_recover_r.reshape(-1, self.N_t, self.M)
        H_recover_i = H_recover_i.reshape(-1, self.N_t, self.M)
        # (b * K, N_t, M)
        
        H_recover = torch.stack((H_recover_r, H_recover_i), dim = 1)
        # (b * K, 2, N_t, M)

        '''
        H_recover = h_recover.reshape(h_recover.shape[0], 2, self.N_p)
        H_recover = H_recover.unsqueeze(dim = 3).repeat(1, 1, 1, self.M)
        '''
        
        H_shortcut = H_recover

        # CNN for residual learning
        H_recover = self.cb1(H_recover)
        H_recover = self.cb2(H_recover)
        H_recover = self.cb3(H_recover)
        H_recover = self.cb4(H_recover)
        H_recover = self.cb5(H_recover)
      
        H_recover = nn.AvgPool2d(kernel_size=(H_recover.shape[2], H_recover.shape[3]))(H_recover)
        H_recover = self.drop_out(H_recover.squeeze(dim = 3).squeeze(dim = 2))
        H_recover = self.fc_out(H_recover)
        
        H_recover = H_recover.reshape(H_recover.shape[0], 2, self.N_t, self.M)
        
        H_recover = H_recover + weight_sum * H_shortcut
        
        # 2-norm
        H_recover = H_recover.reshape(H_recover.shape[0], -1) # (b * K, 2 * N_t * M)
        H_recover_2 = torch.linalg.norm(H_recover, dim = 1)
        H_recover = H_recover.permute(1, 0) / H_recover_2
        H_recover = H_recover.permute(1, 0)
        
        H_recover = H_recover.reshape(H_recover.shape[0], 2, self.N_t, self.M) # (b * K, 2, N_t, M)
        
        return H_recover
